import firebase from 'firebase';

  const firebaseConfig = {  

    apiKey: "AIzaSyBKidhX32-aZJF2ocM4OuhzXBW4tw8oaJQ",
    authDomain: "swapswap-f35d4.firebaseapp.com",
    projectId: "swapswap-f35d4",
    storageBucket: "swapswap-f35d4.appspot.com",
    messagingSenderId: "460717339322",
    appId: "1:460717339322:web:652adcb4c8574228b18883",
    measurementId: "G-RJWSCMKHW8"
    

  };

  // Initialize Firebase
  const fire = firebase.initializeApp(firebaseConfig);

  

  const storage = firebase.storage();

  export {storage, fire as default };