// @refresh reset
import React, { useState, useEffect, useRef } from 'react'
import { 
  StyleSheet, 
  Text, 
  View,
  LogBox,
  Dimensions,
  Animated,
  SafeAreaView,
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage'
import * as firebase from 'firebase'
import 'firebase/firestore'


const {width, height} = Dimensions.get('screen');


LogBox.ignoreAllLogs()

const firebaseConfig = {  

  apiKey: "AIzaSyBKidhX32-aZJF2ocM4OuhzXBW4tw8oaJQ",
  authDomain: "swapswap-f35d4.firebaseapp.com",
  projectId: "swapswap-f35d4",
  storageBucket: "swapswap-f35d4.appspot.com",
  messagingSenderId: "460717339322",
  appId: "1:460717339322:web:652adcb4c8574228b18883",
  measurementId: "G-RJWSCMKHW8"
  

};




if(firebase.apps.length === 0) {
  firebase.initializeApp(firebaseConfig)
}

const db = firebase.firestore()
const imgRef = db.collection('swapList')


function useWishes() {
    const [imgss, setWishes] = useState([])
    useEffect(() => {
      const unsubscribe = imgRef.onSnapshot((snapshot) => {
        const newWishes = snapshot.docs.map((doc)=> (
         {
          id: doc.id,
          name: doc.name,
          imageURL: doc.imageURL,
          positionX: doc.positionX,
          positionY: doc.positionY,
          centered: doc.centered,
          width: doc.width,
          height: doc.height,
          swipeDegrees: doc.swipeDegrees,
            ...doc.data()
        }))
        setWishes(newWishes)
    })
    return () => unsubscribe()
    }, [])
    return imgss
  }


const Swap = () => {
    const xScroll = useRef(new Animated.Value(0)).current;
    const imgss = useWishes();
    
    return(
      <View style={style.container}>
      <Animated.FlatList
        style={style.flatList}
        data={imgss}
        horizontal
        showsHorizontalScrollIndicator={false}
        snapToInterval={width}
        decelerationRate={'fast'}
        keyExtractor={(_, index) => index.toString()}
        onScroll={Animated.event(
          [{nativeEvent: {contentOffset: {x: xScroll}}}],
          {useNativeDriver: true},
        )}
        renderItem={({item, index}) => {
          const inputRange = [
            (index - 1) * width,
            index * width,
            (index + 1) * width,
          ];
          const outputRange = [item.swipeDegrees[0], item.swipeDegrees[1], item.swipeDegrees[2]];
          // const outputRange = ['-90deg', '0deg', '90deg'];

          const translateX = xScroll.interpolate({inputRange, outputRange});

          return (
            <SafeAreaView>
            <View style={style.imageContainer}>
              <Animated.Image
                style={[style.image,{
                  height: item.height,
                  width: item.width,
                },
                item.centered === false && 
                {
                  top: item.positionX,
                  left: item.positionY,
                  position: 'absolute'
                },
                {transform: [{rotateZ: translateX}]}]}
                source={{uri: item.imageURL}}
              />
            </View>
            </SafeAreaView>
          );
        }}
      />
    </View>
    )};


const style = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  flatList: {
    flexGrow: 0,
  },
  imageContainer: {
    width: width,
    height: height,
    alignItems: 'center',
    justifyContent: 'center',
  },
  image: {
    borderRadius: 50,
    resizeMode: 'cover',
  },
});



export default Swap;